#ifndef _SEMANTIC_H_ 
#define _SEMANTIC_H_ 
#include <stdio.h> 
#include <stdlib.h> 
#include "treeNode.h"
#include "symbolTable.h"

void printTreeSemantic(TreeNode *tree);
void addIOLibrary(TreeNode *tree);

#endif
