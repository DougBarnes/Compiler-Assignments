#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "semantic.h"
#include "treeNode.h"
#include "symbolTable.h"

const char* expTypeCheck(ExpType type);

SymbolTable symbolTable;
extern int numErrors;
extern int numWarning;

int scopeDepth = 1;
bool scopeEntered = false;

void printTreeSemantic(TreeNode *tree)
{
	int i;
	
		if (tree == NULL)
		{
			return;
		}

		if (tree->nodekind==DeclK)
		{ 
		  	TreeNode *functionName;
			if(symbolTable.insert(tree->attr.name, tree) == 0 /*&& tree->subkind.decl != VarK*/)
			{
				functionName = (TreeNode*)symbolTable.lookup(tree->attr.name); 
				printf("ERROR(%d): Symbol '%s' is already declared at line %d.\n", tree->linenum, tree->attr.name, functionName->linenum);
				numErrors++;
			}
		  	switch (tree->subkind.decl) {
				case VarK:
				  //printf("VarK: %s\n", tree->attr.name);
				  for(int i = 0; i<MAXCHILDREN; i++)
				  {
				  	printTreeSemantic(tree->child[i]);
				  }

				  /*TreeNode *variableName;
				  if(symbolTable.insert(tree->attr.name, tree) == 0)
				  {
				 	variableName = (TreeNode*)symbolTable.lookup(tree->attr.name); 
					printf("ERROR(%d): Symbol '%s' is already declared at line %d.\n", tree->linenum, tree->attr.name, variableName->linenum);
					numErrors++;
				  }*/
				  break;
				case FuncK:
				  //printf("FuncK: %s\n", tree->attr.name);	  
				  //scope stuff needs to happen here
				  symbolTable.enter(tree->attr.name);
				  scopeDepth++;
				  //printf("ENTERED SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				  scopeEntered = true;
				  for(int i = 0; i<MAXCHILDREN; i++)
				  {
					 printTreeSemantic(tree->child[i]);
				  }
				  symbolTable.leave();
				  scopeDepth--;
				  //printf("LEFT SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				  break;
				case ParamK:
				  //printf("ParamK: %s\n",tree->attr.name);

				  for(int i = 0; i<MAXCHILDREN; i++)
				  {
				  	printTreeSemantic(tree->child[i]);
				  }
				  break;
				default:
				  printf("Unknown ExpNode kind\n");
				  break;
			}
		}
    	else if (tree->nodekind==StmtK)
    	{ switch (tree->subkind.stmt) {
        	case IfK:
				//printf("If\n");
				//scope stuff needs to happen here
				symbolTable.enter("if");
				scopeDepth++;
				//printf("ENTERED SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				scopeEntered = true;
				for(int i = 0; i<MAXCHILDREN; i++)
				{
					printTreeSemantic(tree->child[i]);
				}
				symbolTable.leave();
				scopeDepth--;
				//printf("LEFT SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				scopeEntered = false;
          		break;
        	case WhileK:
          		//printf("While: \n");
				//scope stuff needs to happen here
				symbolTable.enter("while");
				scopeDepth++;
				//printf("ENTERED SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				scopeEntered = true;
				for(int i = 0; i<MAXCHILDREN; i++)
				{
					printTreeSemantic(tree->child[i]);
				}
				symbolTable.leave();
				scopeDepth--;
				//printf("LEFT SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				scopeEntered = false;
          		break;
        	case ForK:
          		//printf("For: \n");
				//scope stuff needs to happen here
				symbolTable.enter("for");
				scopeDepth++;
				//printf("ENTERED SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				scopeEntered = true;
				for(int i = 0; i<MAXCHILDREN; i++)
				{
					printTreeSemantic(tree->child[i]);
				}
				symbolTable.leave();
				scopeDepth--;
				//printf("LEFT SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				scopeEntered = false;
          		break;
        	case CompoundK: {
		      	//printf("Compound: \n");
				//scope stuff needs to happen here
				bool scopeView = scopeEntered;
				if(!scopeView)
				{
					symbolTable.enter("compound");
					scopeDepth++;
					//printf("ENTERED SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				}
				else
				{
					scopeEntered = false;
				}
				for(int i = 0; i<MAXCHILDREN; i++)
				{
					printTreeSemantic(tree->child[i]);
				}
				if(!scopeView)
				{
					symbolTable.leave();
					scopeDepth--;
					//printf("LEFT SCOPE!	Scope Depth: %d	Name: %s	Line Number: %d\n", scopeDepth, tree->attr.name, tree->linenum);
				}
          		break; }
        	case ReturnK:
          		//printf("ReturnK\n");
				printTreeSemantic(tree->child[0]);
				if(tree->child[0] != NULL)
				{
					if(tree->child[0]->isArray)
					{
						numErrors++;
						printf("ERROR(%d): Cannot return an array.\n", tree->child[0]->linenum);
					}
				}
          		break;
			case BreakK:
          		//printf("BreakK\n");
          		break;
			case RangeK:
				//scope stuff needs to happen here
          		//printf("RangeK\n");
          		break;
        	default:
          		printf("Unknown ExpNode kind\n");
          		break;
      	}
    }
    else if (tree->nodekind==ExpK)
    { switch (tree->exp) {
//////////////////////////////////////// AssignK ////////////////////////////////////////
 		case AssignK: {
			TreeNode *leftAssignLookUp;
			TreeNode *rightAssignLookUp;

			for(int i = 0; i<MAXCHILDREN; i++)
			{	
				printTreeSemantic(tree->child[i]);
			}

			if(tree->child[0] != NULL)
			{

				leftAssignLookUp = (TreeNode*)symbolTable.lookup(tree->child[0]->attr.name);
				if(leftAssignLookUp != NULL)
				{
					tree->child[0]->expType = leftAssignLookUp->expType;
					tree->child[0]->isArray = leftAssignLookUp->isArray;
				}
			}
			
			if(tree->child[1] == NULL)	/*is unary*/
			{
				tree->expType = Integer;
				if(tree->child[0]->isArray)
				{
					numErrors++;
					printf("ERROR(%d): The operation '%s' does not work with arrays.\n", tree->child[0]->linenum, tree->attr.name);
				}
				if(tree->child[0]->expType != Integer)
				{
					numErrors++;
					printf("ERROR(%d): Unary '%s' requires an operand of type int but was given type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType));
				}
			}
			else // is not unary
			{

				if(tree->child[1] != NULL)
				{
					if(tree->child[1]->exp == IdK)
					{
						rightAssignLookUp = (TreeNode*)symbolTable.lookup(tree->child[1]->attr.name);
						if(rightAssignLookUp != NULL)
						{
							tree->child[1]->expType = rightAssignLookUp->expType;
							tree->child[1]->isArray = rightAssignLookUp->isArray;

					  		//printf("AssignK: %s		Tree Name: %s	Child Name: %s		Line: %d\n",expTypeCheck(tree->child[1]->expType), tree->attr.name, tree->child[1]->attr.name, tree->linenum);
							
							if(strcmp(tree->attr.name, "=") == 0)
							{
								//printf("Tree name: %s 	LineNumber %d	Child 0: %d		Child 1: %d\n", tree->attr.name, tree->linenum, tree->child[0]->expType, tree->child[1]->expType);
								//printf("line: %d 	Name: %s	1child name: %s		exptype1: %s	2child name: %s		exptype2:	%s\n", tree->child[0]->linenum, tree->attr.name, tree->child[0]->attr.name ,expTypeCheck(tree->child[0]->expType), tree->child[1]->attr.name ,expTypeCheck(tree->child[1]->expType));
								tree->expType = tree->child[0]->expType;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								} 
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
							}
							else
							{
								//printf("line: %d 	Name: %s	1child name: %s		exptype1: %s\n", tree->child[0]->linenum, tree->attr.name, tree->child[0]->attr.name ,expTypeCheck(tree->child[0]->expType));
								tree->expType = Integer;
								if(tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)
								{
									if(tree->child[0]->expType != Integer)
									{
										numErrors++;
										printf("ERROR(%d): '%s' requires operands of type int but lhs is of type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType));
									}
									if(tree->child[1]->expType != Integer)
									{
										numErrors++;
										printf("ERROR(%d): '%s' requires operands of type int but rhs is of type %s.\n", tree->child[1]->linenum, tree->attr.name, expTypeCheck(tree->child[1]->expType));
									}
								}
								if(tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): The operation '%s' does not work with arrays.\n", tree->child[1]->linenum, tree->attr.name);
								}
								if(tree->child[0]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): The operation '%s' does not work with arrays.\n", tree->child[0]->linenum, tree->attr.name);
								}
							}
						}
					}
					else
					{
						if(strcmp(tree->attr.name, "=") == 0)
						{
							//printf("Tree name: %s 	LineNumber %d	Child 0: %d		Child 1: %d\n", tree->attr.name, tree->linenum, tree->child[0]->expType, tree->child[1]->expType);
							//printf("line: %d 	Name: %s	1child name: %s		exptype1: %s	2child name: %s		exptype2: %s\n", tree->child[0]->linenum, tree->attr.name, tree->child[0]->attr.name ,expTypeCheck(tree->child[0]->expType), tree->child[1]->attr.name ,expTypeCheck(tree->child[1]->expType));
							tree->expType = tree->child[0]->expType;
							if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
							}
							if(tree->child[0]->isArray && !tree->child[1]->isArray)
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
							}
							if(!tree->child[0]->isArray && tree->child[1]->isArray)
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
							}
						}
						else
						{
							//printf("line: %d 	Name: %s	1child name: %s		exptype1: %s\n", tree->child[0]->linenum, tree->attr.name, tree->child[0]->attr.name ,expTypeCheck(tree->child[0]->expType));
							tree->expType = Integer;
							
							if(tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)
							{
								if(tree->child[0]->expType != Integer)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of type int but lhs is of type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType));
								}
								if(tree->child[1]->expType != Integer)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of type int but rhs is of type %s.\n", tree->child[1]->linenum, tree->attr.name, expTypeCheck(tree->child[1]->expType));
								}
							}
							if(tree->child[1]->isArray)
							{
								numErrors++;
								printf("ERROR(%d): The operation '%s' does not work with arrays.\n", tree->child[1]->linenum, tree->attr.name);
							}
							if(tree->child[0]->isArray)
							{
								numErrors++;
								printf("ERROR(%d): The operation '%s' does not work with arrays.\n", tree->child[0]->linenum, tree->attr.name);
							}
						}
					}
					
				}
				/*if(leftAssignLookUp != NULL)
				{
					//TreeNode *rightAssignLookUp = tree->child[1];
					//printf("Right Assign: %s	Left Assign: %s\n", rightAssignLookUp->attr.name, leftAssignLookUp->attr.name);
				}*/
				
				/*if(assignLookUp->subkind.decl != VarK)
				{
					printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", tree->child[0]->linenum);
				}*/
			}
          	break; }  
//////////////////////////////////////// OpK //////////////////////////////////////// 
		case OpK: {
          	//printf("Op: %s	Line: %d\n",tree->attr.name, tree->linenum);
			TreeNode *leftOpLookUp;
			TreeNode *rightOpLookUp;

			for(int i = 0; i<MAXCHILDREN; i++)
			{
				printTreeSemantic(tree->child[i]);
				tree->expType = UndefinedType;
			}
			//tree->expType = UndefinedType;
			//printf("HERE IS SEG linenumber: %d 	name: %s\n",tree->child[0]->linenum, tree->attr.name);
			if(tree->child[0] != NULL && tree->child[0]->exp == IdK)
			{
				leftOpLookUp = (TreeNode*)symbolTable.lookup(tree->child[0]->attr.name);
				if(leftOpLookUp != NULL)
				{
					tree->child[0]->expType = leftOpLookUp->expType;
					tree->child[0]->isArray = leftOpLookUp->isArray;
				}

			}
			
			if(tree->child[1] == NULL) // is unary
			{
				if(strcmp(tree->attr.name, "NOT") == 0)
				{
					tree->expType = Boolean;
					if(tree->child[0]->expType != Boolean && tree->child[0]->expType != UndefinedType)	
					{
						numErrors++;
						printf("ERROR(%d): Unary 'not' requires an operand of type bool but was given type %s.\n", tree->child[0]->linenum, expTypeCheck(tree->child[0]->expType));
					}
					tree->isArray = tree->child[0]->isArray;
					if(tree->child[0]->isArray)
					{
						numErrors++;
						printf("ERROR(%d): The operation 'not' does not work with arrays.\n", tree->child[0]->linenum);
					}

				}

				if(strcmp(tree->attr.name, "-") == 0)
				{
					tree->expType = Integer;
					if(tree->child[0]->expType != Integer && tree->child[0]->expType != UndefinedType)	
					{
						numErrors++;
						printf("ERROR(%d): Unary 'chsign' requires an operand of type int but was given type %s.\n", tree->child[0]->linenum, expTypeCheck(tree->child[0]->expType));
					}
					//tree->isArray = tree->child[0]->isArray;
					if(tree->child[0]->isArray)
					{
						numErrors++;
						printf("ERROR(%d): The operation 'chsign' does not work with arrays.\n", tree->child[0]->linenum);
					}
				}
				if(strcmp(tree->attr.name, "*") == 0)
				{
					tree->expType = Integer;
					//tree->isArray = tree->child[0]->isArray;
					if(!tree->child[0]->isArray)
					{
						numErrors++;
						printf("ERROR(%d): The operation 'sizeof' only works with arrays.\n", tree->child[0]->linenum);
					}

				}
				if(strcmp(tree->attr.name, "?") == 0)
				{
					tree->expType = Integer;
					if(tree->child[0]->expType != Integer && tree->child[0]->expType != UndefinedType)	
					{
						numErrors++;
						printf("ERROR(%d): Unary '?' requires an operand of type int but was given type %s.\n", tree->child[0]->linenum, expTypeCheck(tree->child[0]->expType));
					}
					tree->isArray = tree->child[0]->isArray;
					if(tree->child[0]->isArray)
					{
						numErrors++;
						printf("ERROR(%d): The operation '?' does not work with arrays.\n", tree->child[0]->linenum);
					}

				}
			}
			else // is not unary
			{

				if(tree->child[1] != NULL)
				{

					if(tree->child[1]->exp == IdK)
					{

						rightOpLookUp = (TreeNode*)symbolTable.lookup(tree->child[1]->attr.name);
						if(rightOpLookUp != NULL)
						{
							tree->child[1]->expType = rightOpLookUp->expType;
							tree->child[1]->isArray = rightOpLookUp->isArray;


							if(strcmp(tree->attr.name, "AND") == 0)
							{
								tree->expType = Boolean;
								if(tree->child[0]->expType != Boolean)	
								{
									numErrors++;
									printf("ERROR(%d): 'and' requires operands of type bool but lhs is of type %s.\n", tree->child[0]->linenum, expTypeCheck(tree->child[0]->expType));
								}
								if(tree->child[1]->expType != Boolean)	
								{
									numErrors++;
									printf("ERROR(%d): 'and' requires operands of type bool but rhs is of type %s.\n", tree->child[1]->linenum, expTypeCheck(tree->child[1]->expType));
								}
								tree->isArray = tree->child[0]->isArray;
								if(tree->child[0]->isArray || tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): The operation 'and' does not work with arrays.\n", tree->child[0]->linenum);
								}
									//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, "OR") == 0)
							{
								tree->expType = Boolean;
								if(tree->child[0]->expType != Boolean)	
								{
									numErrors++;
									printf("ERROR(%d): 'or' requires operands of type bool but lhs is of type %s.\n", tree->child[0]->linenum, expTypeCheck(tree->child[0]->expType));
								}
								if(tree->child[1]->expType != Boolean)	
								{
									numErrors++;
									printf("ERROR(%d): 'or' requires operands of type bool but rhs is of type %s.\n", tree->child[1]->linenum, expTypeCheck(tree->child[1]->expType));
								}
								tree->isArray = tree->child[0]->isArray;
								if(tree->child[0]->isArray || tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): The operation 'or' does not work with arrays.\n", tree->child[0]->linenum);
								}
									//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, "==") == 0)
							{
								//tree->expType = tree->child[0]->expType;
								tree->expType = Boolean;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
										
										//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
								}

							else if(strcmp(tree->attr.name, "!=") == 0)
							{
								//tree->expType = tree->child[0]->expType;
								tree->expType = Boolean;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}

									//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, "<=") == 0)
							{
								//tree->expType = tree->child[0]->expType;
								tree->expType = Boolean;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, "<") == 0)
							{
								tree->expType = Boolean;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, ">=") == 0)
							{
								tree->expType = Boolean;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, ">") == 0)
							{
								tree->expType = Boolean;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
									//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, "[") == 0)
							{
								tree->expType = tree->child[0]->expType;
								if(!tree->child[0]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): Cannot index nonarray '%s'.\n", tree->child[0]->linenum, tree->child[0]->attr.name);
								}
								if(tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): Array index is the unindexed array '%s'.\n", tree->child[0]->linenum, tree->child[1]->attr.name);
								}
								if(tree->child[1]->expType != Integer && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): Array '%s' should be indexed by type int but got type %s.\n", tree->child[0]->linenum, tree->child[0]->attr.name, expTypeCheck(tree->child[1]->expType));
								}
								//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else
							{
								tree->expType = Integer;
									//if(tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)
									//{
								if(tree->child[0]->expType != Integer)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of type int but lhs is of type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType));
								}
								if(tree->child[1]->expType != Integer)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of type int but rhs is of type %s.\n", tree->child[1]->linenum, tree->attr.name, expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray || tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): The operation '%s' does not work with arrays.\n", tree->child[1]->linenum, tree->attr.name);
								}

							}
									
						}
					}
					else
					{
						if(strcmp(tree->attr.name, "AND") == 0)
						{
							tree->expType = Boolean;
							if(tree->child[0]->expType != Boolean)	
							{
								numErrors++;
								printf("ERROR(%d): 'and' requires operands of type bool but lhs is of type %s.\n", tree->child[0]->linenum, expTypeCheck(tree->child[0]->expType));
							}
							if(tree->child[1]->expType != Boolean)	
							{
								numErrors++;
								printf("ERROR(%d): 'and' requires operands of type bool but rhs is of type %s.\n", tree->child[1]->linenum, expTypeCheck(tree->child[1]->expType));
							}
							//tree->isArray = tree->child[0]->isArray;
							if(tree->child[0]->isArray || tree->child[1]->isArray)
							{
								numErrors++;
								printf("ERROR(%d): The operation 'and' does not work with arrays.\n", tree->child[0]->linenum);
							}
									//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
						}
						else if(strcmp(tree->attr.name, "OR") == 0)
						{
							tree->expType = Boolean;
							if(tree->child[0]->expType != Boolean)	
							{
								numErrors++;
								printf("ERROR(%d): 'or' requires operands of type bool but lhs is of type %s.\n", tree->child[0]->linenum, expTypeCheck(tree->child[0]->expType));
							}
							if(tree->child[1]->expType != Boolean)	
							{
								numErrors++;
								printf("ERROR(%d): 'or' requires operands of type bool but rhs is of type %s.\n", tree->child[1]->linenum, expTypeCheck(tree->child[1]->expType));
							}
							//tree->isArray = tree->child[0]->isArray;
							if(tree->child[0]->isArray || tree->child[1]->isArray)
							{
								numErrors++;
								printf("ERROR(%d): The operation 'or' does not work with arrays.\n", tree->child[0]->linenum);
							}
									//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
						}
						else if(strcmp(tree->attr.name, "==") == 0)
						{
							//tree->expType = tree->child[0]->expType;
							tree->expType = Boolean;
							if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
							}
							if(tree->child[0]->isArray && !tree->child[1]->isArray)
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
							}
							if(!tree->child[0]->isArray && tree->child[1]->isArray)
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
							}
									
								//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
						}
						else if(strcmp(tree->attr.name, "!=") == 0)
						{
							tree->expType = Boolean;
							if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
							}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}

							//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
						}
						else if(strcmp(tree->attr.name, "<=") == 0)
						{
							tree->expType = Boolean;
							if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
							}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
							//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
						}
						else if(strcmp(tree->attr.name, "<") == 0)
						{
							tree->expType = Boolean;
							if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
							{
								numErrors++;
								printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
							}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
							//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
						}
							else if(strcmp(tree->attr.name, ">=") == 0)
							{
								tree->expType = Boolean;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, ">") == 0)
							{
								tree->expType = Boolean;
								if(tree->child[0]->expType != tree->child[1]->expType && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType), expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray && !tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is an array and rhs is not an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
								if(!tree->child[0]->isArray && tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is not an array and rhs is an array.\n", tree->child[0]->linenum, tree->attr.name);
								}
									//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else if(strcmp(tree->attr.name, "[") == 0)
							{
								tree->expType = tree->child[0]->expType;
								if(!tree->child[0]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): Cannot index nonarray '%s'.\n", tree->child[0]->linenum, tree->child[0]->attr.name);
								}
								if(tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): Array index is the unindexed array '%s'.\n", tree->child[0]->linenum, tree->child[1]->attr.name);
								}
								if(tree->child[1]->expType != Integer && tree->child[0]->expType != UndefinedType && tree->child[1]->expType != UndefinedType)	
								{
									numErrors++;
									printf("ERROR(%d): Array '%s' should be indexed by type int but got type %s.\n", tree->child[0]->linenum, tree->child[0]->attr.name, expTypeCheck(tree->child[1]->expType));
								}
								//printf("TEST(%d): 	'%s'\n", tree->child[0]->linenum, tree->attr.name);
							}
							else
							{
								tree->expType = Integer;

								if(tree->child[0]->expType != Integer)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of type int but lhs is of type %s.\n", tree->child[0]->linenum, tree->attr.name, expTypeCheck(tree->child[0]->expType));
								}
								if(tree->child[1]->expType != Integer)
								{
									numErrors++;
									printf("ERROR(%d): '%s' requires operands of type int but rhs is of type %s.\n", tree->child[1]->linenum, tree->attr.name, expTypeCheck(tree->child[1]->expType));
								}
								if(tree->child[0]->isArray || tree->child[1]->isArray)
								{
									numErrors++;
									printf("ERROR(%d): The operation '%s' does not work with arrays.\n", tree->child[1]->linenum, tree->attr.name);
								}

							}
					}
			
				}

			}
          break; }
//////////////////////////////////////// IdK ////////////////////////////////////////
        case IdK: {
			TreeNode *idLookUp = (TreeNode*)symbolTable.lookup(tree->attr.name);
			tree->expType = UndefinedType;
         	//printf("Id: %s\n",tree->attr.name);
			if(idLookUp == NULL)
			{
				numErrors++;
				printf("ERROR(%d): Symbol '%s' is not declared.\n", tree->linenum, tree->attr.name);
			}
			else
			{
				tree->subkind.decl = idLookUp->subkind.decl; 
				tree->expType = idLookUp->expType;
				tree->isArray = idLookUp->isArray;
				if(tree->subkind.decl == FuncK)
				{
					
					numErrors++;
					printf("ERROR(%d): Cannot use function '%s' as a variable.\n", tree->linenum, tree->attr.name);
				}

				/*for(int i = 0; i<MAXCHILDREN; i++)
				{
					if(tree->child[i] != NULL)
					{
						printf("In ID loop, NAME: %s", tree->child[i]->attr.name);
					}
					printTreeSemantic(tree->child[i]);
					if(tree->child[i] != NULL)//
					{
						if(!tree->child[i]->isArray && tree->exp == OpK)
						{
							printf("ERROR(%d): Cannot index nonarray '%s'.\n", tree->linenum, tree->attr.name);
						}
					}
				}*/
			}

          break; }
		case ConstantK:
          //printf("Const: \n");
          break;
        case InitK:
          //printf("InitK: %s\n",tree->attr.name);
          break;

        case CallK: {
          	//printf("CallK: %s\n",tree->attr.name);

			TreeNode *callLookUp = (TreeNode*)symbolTable.lookup(tree->attr.name);

			for(int i = 0; i<MAXCHILDREN; i++)
			{
				printTreeSemantic(tree->child[i]);
			}
			if(callLookUp == NULL)
			{
				numErrors++;
				printf("ERROR(%d): Symbol '%s' is not declared.\n", tree->linenum, tree->attr.name);
			}
			else if(callLookUp->subkind.decl != FuncK)
			{
				numErrors++;
				printf("ERROR(%d): '%s' is a simple variable and cannot be called.\n", tree->linenum, tree->attr.name);
			}
			else
			{
				tree->expType = callLookUp->expType;
			}
          break; }

        default:
          printf("Unknown ExpNode kind\n");
          break;
      }
    }
    else printf("Unknown node kind\n");
	
	if(tree->sibling != NULL)
	{
		printTreeSemantic(tree->sibling);
	}

}

const char* expTypeCheck(ExpType type)
{
	switch(type){
		case 0:
			return "void";
		break;
		case 1:
			return "int";
		break;
		case 2:
			return "bool";
		break;
		case 3:
			return "char";
		break;
		case 4:
			return "CharInt";
		break;
		case 5:
			return "Equal";
		break;
		case 6:
			return "UndefinedType";
		break;
		
	}
}





